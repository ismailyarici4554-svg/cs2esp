#include <Windows.h>
#include <array>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <cmath>
#include "memory.hpp"
#include "offsets.hpp"
#include "renderer.hpp"

struct Vec3 { float x, y, z; };
using M44 = std::array<float, 16>;

static bool IsHeap(uintptr_t p) { return p > 0x10000 && p < 0x700000000000ULL && !(p & 3); }

bool W2S(const Vec3& pos, const M44& m, float sw, float sh, float& ox, float& oy) {
    float w = m[12]*pos.x + m[13]*pos.y + m[14]*pos.z + m[15];
    if (w < 0.001f) return false;
    ox = sw/2 + (sw/2) * (m[0]*pos.x + m[1]*pos.y + m[2]*pos.z + m[3]) / w;
    oy = sh/2 - (sh/2) * (m[4]*pos.x + m[5]*pos.y + m[6]*pos.z + m[7]) / w;
    return true;
}

M44 ReadVM(const Memory& mem) {
    M44 m{}; uintptr_t a = mem.clientBase + offsets::dwViewMatrix;
    for (int i = 0; i < 16; ++i) m[i] = mem.Read<float>(a + i*4);
    return m;
}

static constexpr int BONE_CNT = 28;
static uintptr_t g_boneOff = 0; // discovered once, used globally

struct Ent {
    Vec3 foot; int hp, team;
    Vec3 bones[BONE_CNT]; bool hasBones;
};

static uint8_t g_boneBuf[BONE_CNT * 0x20]; // shared bone read buffer

// Bone pozisyonlarini (foot + bones) sceneNode'dan guncelle — per-frame cagrilir
static void RefreshBones(const Memory& mem, uintptr_t sn, Ent& e) {
    Vec3 ft = mem.Read<Vec3>(sn + 0xC8);
    if (!std::isfinite(ft.x) || fabsf(ft.x) > 32768.f || (ft.x==0.f&&ft.y==0.f&&ft.z==0.f)) return;
    e.foot = ft;

    if (g_boneOff == 0) return;
    uintptr_t bp = mem.Read<uintptr_t>(sn + g_boneOff);
    if (!IsHeap(bp)) return;
    if (mem.ReadBulk(bp, g_boneBuf, sizeof(g_boneBuf)) < sizeof(g_boneBuf)) return;
    bool ok = true;
    for (int i = 0; i < BONE_CNT; i++) {
        e.bones[i] = *reinterpret_cast<Vec3*>(g_boneBuf + i * 0x20);
        if (!std::isfinite(e.bones[i].x)) { ok = false; break; }
    }
    if (ok) {
        float dz = e.bones[6].z - ft.z;
        e.hasBones = (dz > 10.f && dz < 160.f);
    }
}

bool ReadEnt(const Memory& mem, uintptr_t p, Ent& e, uintptr_t& outSn) {
    int hp = mem.Read<int32_t>(p + 0x34C);
    if (hp <= 0 || hp > 100) return false;
    int tm = mem.Read<uint8_t>(p + 0x3E7);
    if (tm != 2 && tm != 3) return false; // sadece T(2) ve CT(3)
    uintptr_t sn = mem.Read<uintptr_t>(p + 0x330);
    if (!IsHeap(sn)) return false;
    Vec3 foot = mem.Read<Vec3>(sn + 0xC8);
    if (!std::isfinite(foot.x) || !std::isfinite(foot.y) || !std::isfinite(foot.z)) return false;
    if (fabsf(foot.x) > 32768.f || fabsf(foot.y) > 32768.f || fabsf(foot.z) > 32768.f) return false;
    if (foot.x == 0.f && foot.y == 0.f && foot.z == 0.f) return false;
    e.foot = foot; e.hp = hp; e.team = tm; e.hasBones = false;
    outSn = sn;

    // bone pointer offset otomatik bul (bir kez)
    static const uintptr_t BONE_CANDS[] = {
        0x1E8, 0x1E0, 0x1D8, 0x1D0, 0x1C8, 0x1C0,
        0x1B8, 0x1B0, 0x1A8, 0x1A0, 0x1F0, 0x200
    };
    if (g_boneOff == 0) {
        for (uintptr_t off : BONE_CANDS) {
            uintptr_t tbp = mem.Read<uintptr_t>(sn + off);
            if (!IsHeap(tbp)) continue;
            uint8_t test[7 * 0x20]{};
            if (mem.ReadBulk(tbp, test, sizeof(test)) < sizeof(test)) continue;
            Vec3 h = *reinterpret_cast<Vec3*>(test + 6 * 0x20);
            float dz = h.z - foot.z;
            if (std::isfinite(h.z) && dz > 10.f && dz < 160.f) { g_boneOff = off; break; }
        }
    }
    RefreshBones(mem, sn, e);
    return true;
}

static std::vector<uint8_t> g_buf(1024 * 1024);

struct CachedEnt { Ent e; DWORD ts; uintptr_t sn; };
static std::unordered_map<uintptr_t, CachedEnt> g_cache;
static uintptr_t g_prevEsSys = 0;

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
    Memory mem; Renderer rnd;
    while (!mem.Attach(L"cs2.exe")) { MessageBoxW(nullptr, L"CS2 yok", L"ESP", MB_OK); return 1; }
    if (!rnd.Init()) return 1;

    const float SW = (float)rnd.W, SH = (float)rnd.H;
    bool on = true, prev = false;

    while (true) {
        MSG msg{};
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) return 0;
            TranslateMessage(&msg); DispatchMessageW(&msg);
        }
        if (GetAsyncKeyState(VK_END) & 1) break;
        SetWindowPos(rnd.hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE);

        bool f8 = GetAsyncKeyState(VK_F8) & 0x8000;
        if (f8 && !prev) on = !on; prev = f8;

        rnd.Begin();
        rnd.DrawText2D(10, 10, on ? L"ESP: ON  [F8]" : L"ESP: OFF [F8]",
                       on ? RGB(0,220,0) : RGB(220,50,50));

        if (!on) { rnd.End(); Sleep(8); continue; }

        M44 vm          = ReadVM(mem);
        uintptr_t lp    = mem.Read<uintptr_t>(mem.clientBase + offsets::dwLocalPlayerPawn);
        int localTeam   = IsHeap(lp) ? mem.Read<uint8_t>(lp + 0x3E7) : 0;
        uintptr_t esSys = mem.Read<uintptr_t>(mem.clientBase + offsets::dwEntityList);

        if (esSys != g_prevEsSys) { g_cache.clear(); g_prevEsSys = esSys; }

        DWORD now = GetTickCount();

        // Entity kesfini 3 frame'de bir yap (yeni dusmanlar, HP, takim)
        static int scanTick = 0;
        if (++scanTick % 3 == 0) {
            std::unordered_set<uintptr_t> seen, scannedChunks;
            seen.reserve(256); scannedChunks.reserve(16);
            for (int co = 0x08; co <= 0x80; co += 8) {
                uintptr_t chunk = mem.Read<uintptr_t>(esSys + co);
                if (!IsHeap(chunk) || !scannedChunks.insert(chunk).second) continue;
                size_t got = mem.ReadBulk(chunk, g_buf.data(), 65536);
                if (got < 8) continue;
                size_t n = got / 8;
                for (size_t i = 0; i < n; ++i) {
                    uintptr_t ptr = *reinterpret_cast<uintptr_t*>(g_buf.data() + i * 8);
                    if (!ptr || ptr == lp || !IsHeap(ptr)) continue;
                    if (!seen.insert(ptr).second) continue;
                    Ent e{}; uintptr_t sn = 0;
                    if (!ReadEnt(mem, ptr, e, sn)) continue;
                    if (localTeam >= 2 && e.team == localTeam) continue;
                    g_cache[ptr] = {e, now, sn};
                }
            }
        }

        // Her frame: cache'teki dusmanların pozisyonunu/iskeletini guncelle (smooth tracking)
        for (auto& [ptr, ce] : g_cache) {
            if (now - ce.ts > 400) continue; // expire edilecek, atlama
            if (IsHeap(ce.sn))
                RefreshBones(mem, ce.sn, ce.e);
        }

        // Ciz
        int cnt = 0;
        for (auto it = g_cache.begin(); it != g_cache.end(); ) {
            if (now - it->second.ts > 400) { it = g_cache.erase(it); continue; }

            const Ent& e = it->second.e;
            Vec3 head = {e.foot.x, e.foot.y, e.foot.z + 75.f};
            float fx, fy, bx, by;
            if (W2S(head, vm, SW, SH, fx, fy) && W2S(e.foot, vm, SW, SH, bx, by)) {
                int bh = (int)(by - fy);
                if (bh > 0 && bh <= 3000) {
                    if (bh < 4) bh = 4;
                    int bw  = bh < 20 ? 4 : (int)(bh * 0.45f);
                    int bx2 = (int)(fx - bw/2), by2 = (int)fy;
                    ++cnt;
                    COLORREF col = e.team == 2 ? RGB(50,150,255)
                                 : e.team == 3 ? RGB(255,50,50)
                                               : RGB(255,220,0);
                    rnd.DrawBox(bx2, by2, bw, bh, col, 2);
                    if (bh >= 8) {
                        rnd.DrawHealthBar(bx2, by2, bh, e.hp);
                        wchar_t hbuf[8]; swprintf_s(hbuf, L"%d", e.hp);
                        rnd.DrawText2D(bx2, by2 - 14, hbuf, col);
                    }
                    if (e.hasBones) {
                        static const struct { int a, b; } SK[] = {
                            {6,5},{5,4},{4,2},{2,0},
                            {5,8},{8,9},{9,10},{10,11},
                            {5,13},{13,14},{14,15},{15,16},
                            {0,22},{22,23},{23,24},
                            {0,25},{25,26},{26,27},
                        };
                        float maxLen = bh * 4.f;
                        COLORREF sc = RGB(255,255,255);
                        for (auto& s : SK) {
                            float lx1,ly1,lx2,ly2;
                            if (!W2S(e.bones[s.a],vm,SW,SH,lx1,ly1)) continue;
                            if (!W2S(e.bones[s.b],vm,SW,SH,lx2,ly2)) continue;
                            float dx = lx2-lx1, dy = ly2-ly1;
                            if (dx*dx+dy*dy > maxLen*maxLen) continue;
                            rnd.DrawLine((int)lx1,(int)ly1,(int)lx2,(int)ly2,sc,2);
                        }
                    }
                }
            }
            ++it;
        }

        wchar_t dbg[16]; swprintf_s(dbg, L"ENM:%d", cnt);
        rnd.DrawText2D(10, 28, dbg, RGB(170,170,170));
        rnd.End();
        Sleep(8);
    }
    return 0;
}
