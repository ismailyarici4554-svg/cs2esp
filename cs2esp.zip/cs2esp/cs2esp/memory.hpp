#pragma once
#include <Windows.h>
#include <TlHelp32.h>
#include <string>
#include <cstdint>

class Memory {
public:
    HANDLE   hProc  = nullptr;
    uintptr_t clientBase = 0;

    bool Attach(const wchar_t* procName) {
        DWORD pid = GetPid(procName);
        if (!pid) return false;

        hProc = OpenProcess(PROCESS_VM_READ, FALSE, pid);
        if (!hProc) return false;

        clientBase = GetModuleBase(pid, L"client.dll");
        return clientBase != 0;
    }

    template<typename T>
    T Read(uintptr_t addr) const {
        T val{};
        ReadProcessMemory(hProc, reinterpret_cast<LPCVOID>(addr), &val, sizeof(T), nullptr);
        return val;
    }

    size_t ReadBulk(uintptr_t addr, void* buf, size_t bytes) const {
        SIZE_T nr = 0;
        ReadProcessMemory(hProc, reinterpret_cast<LPCVOID>(addr), buf, bytes, &nr);
        return nr;
    }

    ~Memory() { if (hProc) CloseHandle(hProc); }

private:
    static DWORD GetPid(const wchar_t* name) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap == INVALID_HANDLE_VALUE) return 0;

        PROCESSENTRY32W pe{ sizeof(pe) };
        DWORD pid = 0;
        if (Process32FirstW(snap, &pe)) {
            do {
                if (_wcsicmp(pe.szExeFile, name) == 0) { pid = pe.th32ProcessID; break; }
            } while (Process32NextW(snap, &pe));
        }
        CloseHandle(snap);
        return pid;
    }

    static uintptr_t GetModuleBase(DWORD pid, const wchar_t* modName) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
        if (snap == INVALID_HANDLE_VALUE) return 0;

        MODULEENTRY32W me{ sizeof(me) };
        uintptr_t base = 0;
        if (Module32FirstW(snap, &me)) {
            do {
                if (_wcsicmp(me.szModule, modName) == 0) { base = reinterpret_cast<uintptr_t>(me.modBaseAddr); break; }
            } while (Module32NextW(snap, &me));
        }
        CloseHandle(snap);
        return base;
    }
};
