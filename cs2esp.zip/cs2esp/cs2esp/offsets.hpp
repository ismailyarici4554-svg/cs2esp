#pragma once
#include <cstdint>

// CS2 — client.dll relative offsets
// Dumped: 2026-11-12 via https://github.com/a2x/cs2-dumper

namespace offsets {
    constexpr uintptr_t dwEntityList      = 0x2709010;  // CGameEntitySystem*
    constexpr uintptr_t dwViewMatrix      = 0x2559640;  // float[4][4]
    constexpr uintptr_t dwLocalPlayerPawn = 0x2553D38;  // C_CSPlayerPawn*
}

namespace schema {
    // C_BaseEntity / C_CSPlayerPawn (pawn offsets)
    constexpr uintptr_t m_iHealth        = 0x34C;   // int32
    constexpr uintptr_t m_iTeamNum       = 0x3E7;   // uint8
    constexpr uintptr_t m_lifeState      = 0x354;   // uint8  0 = alive
    constexpr uintptr_t m_pGameSceneNode = 0x330;   // ptr -> CGameSceneNode
    constexpr uintptr_t m_vecAbsOrigin   = 0xC8;    // Vector in CGameSceneNode

    // CBasePlayerController
    constexpr uintptr_t m_hPawn          = 0x6BC;   // CHandle<C_BasePlayerPawn> — resolve via entity list

    // CEntityIdentity
    constexpr uintptr_t m_pInstance      = 0x00;    // ptr to actual entity object (at start of identity)
    constexpr uintptr_t entityStride     = 0x78;    // CEntityIdentity size
    constexpr uintptr_t listBase         = 0x10;    // chunk array starts at entitySystem+0x10 (not +0x08)
}
