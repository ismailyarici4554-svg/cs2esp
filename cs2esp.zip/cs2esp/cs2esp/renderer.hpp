#pragma once
#include <Windows.h>
#include <string>
#include <array>

// Transparent click-through overlay window drawn with GDI
class Renderer {
public:
    HWND     hwnd   = nullptr;
    HDC      memDC  = nullptr;
    HBITMAP  memBMP = nullptr;
    int      W = 0, H = 0;

    bool Init() {
        W = GetSystemMetrics(SM_CXSCREEN);
        H = GetSystemMetrics(SM_CYSCREEN);

        WNDCLASSEXW wc{ sizeof(wc) };
        wc.lpfnWndProc   = DefWindowProcW;
        wc.hInstance     = GetModuleHandleW(nullptr);
        wc.lpszClassName = L"CS2ESP_Overlay";
        RegisterClassExW(&wc);

        hwnd = CreateWindowExW(
            WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED,
            L"CS2ESP_Overlay", L"",
            WS_POPUP,
            0, 0, W, H,
            nullptr, nullptr, wc.hInstance, nullptr);

        if (!hwnd) return false;

        // Fully transparent background, opaque drawn content
        SetLayeredWindowAttributes(hwnd, RGB(0, 0, 0), 0, LWA_COLORKEY);
        ShowWindow(hwnd, SW_SHOW);

        HDC hdc  = GetDC(hwnd);
        memDC    = CreateCompatibleDC(hdc);
        memBMP   = CreateCompatibleBitmap(hdc, W, H);
        SelectObject(memDC, memBMP);
        ReleaseDC(hwnd, hdc);
        return true;
    }

    void Begin() {
        HBRUSH bg = CreateSolidBrush(RGB(0, 0, 0));
        RECT r{ 0, 0, W, H };
        FillRect(memDC, &r, bg);
        DeleteObject(bg);
    }

    void End() {
        HDC hdc = GetDC(hwnd);
        BitBlt(hdc, 0, 0, W, H, memDC, 0, 0, SRCCOPY);
        ReleaseDC(hwnd, hdc);
    }

    // axis-aligned bounding box
    void DrawBox(int x, int y, int w, int h, COLORREF col, int thick = 1) {
        HPEN pen = CreatePen(PS_SOLID, thick, col);
        HPEN old = (HPEN)SelectObject(memDC, pen);
        HBRUSH nb = (HBRUSH)GetStockObject(NULL_BRUSH);
        HBRUSH ob = (HBRUSH)SelectObject(memDC, nb);
        Rectangle(memDC, x, y, x + w, y + h);
        SelectObject(memDC, old);
        SelectObject(memDC, ob);
        DeleteObject(pen);
    }

    // filled health bar left of box
    void DrawHealthBar(int bx, int by, int bh, int hp) {
        int barH = (int)(bh * (hp / 100.0f));
        int x    = bx - 6;

        // background
        HBRUSH bg = CreateSolidBrush(RGB(60, 60, 60));
        RECT r{ x, by, x + 4, by + bh };
        FillRect(memDC, &r, bg);
        DeleteObject(bg);

        // health — green->red gradient simplified
        COLORREF hcol = hp > 60 ? RGB(0, 220, 0) : hp > 30 ? RGB(220, 180, 0) : RGB(220, 30, 0);
        HBRUSH hb = CreateSolidBrush(hcol);
        RECT rh{ x, by + (bh - barH), x + 4, by + bh };
        FillRect(memDC, &rh, hb);
        DeleteObject(hb);
    }

    void DrawLine(int x1, int y1, int x2, int y2, COLORREF col, int thick = 1) {
        HPEN pen = CreatePen(PS_SOLID, thick, col);
        HPEN old = (HPEN)SelectObject(memDC, pen);
        MoveToEx(memDC, x1, y1, nullptr);
        LineTo(memDC, x2, y2);
        SelectObject(memDC, old);
        DeleteObject(pen);
    }

    void DrawText2D(int x, int y, const wchar_t* text, COLORREF col) {
        SetTextColor(memDC, col);
        SetBkMode(memDC, TRANSPARENT);
        TextOutW(memDC, x, y, text, (int)wcslen(text));
    }

    ~Renderer() {
        if (memDC)  DeleteDC(memDC);
        if (memBMP) DeleteObject(memBMP);
        if (hwnd)   DestroyWindow(hwnd);
    }
};
